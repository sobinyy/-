package abstractFactory


interface Sauce {
    override fun toString(): String
}
