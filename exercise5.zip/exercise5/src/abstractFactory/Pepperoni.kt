package abstractFactory


interface Pepperoni {
    override fun toString(): String
}
