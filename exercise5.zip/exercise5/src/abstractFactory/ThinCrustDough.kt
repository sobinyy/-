package abstractFactory


class ThinCrustDough : Dough {
    override fun toString(): String {
        return "Thin Crust Dough"
    }
}
