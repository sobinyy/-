package abstractFactory


class ParmesanCheese : Cheese {
    override fun toString(): String {
        return "Shredded Parmesan"
    }
}
