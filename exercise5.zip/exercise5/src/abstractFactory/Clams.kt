package abstractFactory


interface Clams {
    override fun toString(): String
}
