package abstractFactory


class Onion : Veggies {
    override fun toString(): String {
        return "Onion"
    }
}
