package abstractFactory


class Spinach : Veggies {
    override fun toString(): String {
        return "Spinach"
    }
}
