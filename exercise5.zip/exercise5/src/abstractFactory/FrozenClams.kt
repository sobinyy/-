package abstractFactory


class FrozenClams : Clams {
    override fun toString(): String {
        return "Frozen Clams from Chesapeake Bay"
    }
}
