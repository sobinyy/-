package abstractFactory


class ReggianoCheese : Cheese {
    override fun toString(): String {
        return "Reggiano Cheese"
    }
}
