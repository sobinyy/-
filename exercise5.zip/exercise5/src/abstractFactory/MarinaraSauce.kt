package abstractFactory


class MarinaraSauce : Sauce {
    override fun toString(): String {
        return "Marinara Sauce"
    }
}
