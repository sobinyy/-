package abstractFactory


class Eggplant : Veggies {
    override fun toString(): String {
        return "Eggplant"
    }
}
