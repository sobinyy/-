package abstractFactory


class Mushroom : Veggies {
    override fun toString(): String {
        return "Mushrooms"
    }
}
