package abstractFactory


class MozzarellaCheese : Cheese {
    override fun toString(): String {
        return "Shredded Mozzarella"
    }
}
