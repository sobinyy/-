package abstractFactory


interface Cheese {
    override fun toString(): String
}
