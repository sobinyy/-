package abstractFactory

class RedPepper : Veggies {
    override fun toString(): String {
        return "Red Pepper"
    }
}
