package abstractFactory


interface Dough {
    override fun toString(): String
}
