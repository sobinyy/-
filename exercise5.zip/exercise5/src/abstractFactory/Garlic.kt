package abstractFactory


class Garlic : Veggies {
    override fun toString(): String {
        return "Garlic"
    }
}
