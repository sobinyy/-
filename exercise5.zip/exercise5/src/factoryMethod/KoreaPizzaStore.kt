package factoryMethod



class KoreaPizzaStore : PizzaStore() {
    public override fun createPizza(item: String): Pizza? {
       return if (item == "cheese")
           ChicagoStyleCheesePizza()
       else null
    }
}