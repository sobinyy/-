package abstractFactory

class SlicedPepperoni : Pepperoni {
    override fun toString(): String {
        return "Sliced Pepperoni"
    }
}
