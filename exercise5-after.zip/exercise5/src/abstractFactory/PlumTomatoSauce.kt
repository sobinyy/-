package abstractFactory


class PlumTomatoSauce : Sauce {
    override fun toString(): String {
        return "Tomato sauce with plum tomatoes"
    }
}
