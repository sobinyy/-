package abstractFactory


class ThickCrustDough : Dough {
    override fun toString(): String {
        return "ThickCrust style extra thick crust dough"
    }
}
