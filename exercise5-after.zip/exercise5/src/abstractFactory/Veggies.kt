package abstractFactory


interface Veggies {
    override fun toString(): String
}
