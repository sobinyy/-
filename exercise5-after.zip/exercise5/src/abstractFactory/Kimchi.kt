package abstractFactory

interface Kimchi {
    override fun toString(): String
}