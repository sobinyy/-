package abstractFactory


class FreshClams : Clams {
    override fun toString(): String {
        return "Fresh Clams from Long Island Sound"
    }
}
