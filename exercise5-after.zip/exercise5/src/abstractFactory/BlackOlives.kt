package abstractFactory


class BlackOlives : Veggies {
    override fun toString(): String {
        return "Black Olives"
    }
}
