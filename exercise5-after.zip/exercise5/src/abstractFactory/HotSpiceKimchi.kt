package abstractFactory

class HotSpiceKimchi : Kimchi{
    override fun toString(): String {
        return "HotSpice Kimchi"
    }
}

